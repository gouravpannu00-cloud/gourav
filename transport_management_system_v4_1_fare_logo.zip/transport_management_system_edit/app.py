
from flask import Flask,render_template,request,redirect,url_for,flash,send_from_directory
import sqlite3,os,time
from datetime import date
app=Flask(__name__); app.secret_key="tms-secret"
BASE=os.path.dirname(os.path.abspath(__file__)); DB=os.path.join(BASE,"transport.db"); UP=os.path.join(BASE,"uploads")
os.makedirs(UP,exist_ok=True)
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS vehicles(id INTEGER PRIMARY KEY AUTOINCREMENT,vehicle_no TEXT NOT NULL,vehicle_type TEXT,owner TEXT,model TEXT,document TEXT);
    CREATE TABLE IF NOT EXISTS drivers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,license TEXT,document TEXT);
    CREATE TABLE IF NOT EXISTS routes(id INTEGER PRIMARY KEY AUTOINCREMENT,vehicle_id INTEGER,driver_id INTEGER,route_from TEXT,route_to TEXT,fare REAL,trip_date TEXT,shift TEXT);
    CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,route_id INTEGER,expense_type TEXT,amount REAL,note TEXT,expense_date TEXT);
    CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,driver_id INTEGER,attendance_date TEXT,status TEXT,shift TEXT);
    """); c.commit(); c.close()
def upload(f):
    if not f or not f.filename:return ""
    n=str(int(time.time()*1000))+"_"+f.filename.replace(" ","_"); f.save(os.path.join(UP,n)); return n

@app.route("/")
def home():
    c=db(); v=c.execute("select count(*) from vehicles").fetchone()[0]; d=c.execute("select count(*) from drivers").fetchone()[0]
    r=c.execute("select count(*) from routes").fetchone()[0]; fare=c.execute("select coalesce(sum(fare),0) from routes").fetchone()[0]
    exp=c.execute("select coalesce(sum(amount),0) from expenses").fetchone()[0]; c.close()
    return render_template("home.html",v=v,d=d,r=r,fare=fare,exp=exp,profit=fare-exp)

@app.route("/vehicles")
def vehicles():
    c=db(); x=c.execute("select * from vehicles order by id desc").fetchall(); c.close()
    return render_template("vehicles.html",rows=x)
@app.route("/vehicles/add",methods=["GET","POST"])
@app.route("/vehicles/edit/<int:id>",methods=["GET","POST"])
def vehicle_form(id=None):
    c=db(); old=c.execute("select * from vehicles where id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        doc=upload(request.files.get("document"))
        if id:
            if doc:c.execute("update vehicles set vehicle_no=?,vehicle_type=?,owner=?,model=?,document=? where id=?",(request.form["vehicle_no"],request.form["vehicle_type"],request.form["owner"],request.form["model"],doc,id))
            else:c.execute("update vehicles set vehicle_no=?,vehicle_type=?,owner=?,model=? where id=?",(request.form["vehicle_no"],request.form["vehicle_type"],request.form["owner"],request.form["model"],id))
            msg="Vehicle updated!"
        else:
            c.execute("insert into vehicles(vehicle_no,vehicle_type,owner,model,document) values(?,?,?,?,?)",(request.form["vehicle_no"],request.form["vehicle_type"],request.form["owner"],request.form["model"],doc)); msg="Vehicle added!"
        c.commit();c.close();flash(msg);return redirect(url_for("vehicles"))
    c.close();return render_template("vehicle_form.html",x=old,edit=bool(id))
@app.route("/vehicles/delete/<int:id>")
def vehicle_delete(id):
    c=db();c.execute("delete from vehicles where id=?",(id,));c.commit();c.close();flash("Vehicle deleted!");return redirect(url_for("vehicles"))

@app.route("/drivers")
def drivers():
    c=db(); x=c.execute("select * from drivers order by id desc").fetchall(); c.close();return render_template("drivers.html",rows=x)
@app.route("/drivers/add",methods=["GET","POST"])
@app.route("/drivers/edit/<int:id>",methods=["GET","POST"])
def driver_form(id=None):
    c=db(); old=c.execute("select * from drivers where id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        doc=upload(request.files.get("document"))
        if id:
            if doc:c.execute("update drivers set name=?,phone=?,license=?,document=? where id=?",(request.form["name"],request.form["phone"],request.form["license"],doc,id))
            else:c.execute("update drivers set name=?,phone=?,license=? where id=?",(request.form["name"],request.form["phone"],request.form["license"],id))
            msg="Driver updated!"
        else:
            c.execute("insert into drivers(name,phone,license,document) values(?,?,?,?)",(request.form["name"],request.form["phone"],request.form["license"],doc));msg="Driver added!"
        c.commit();c.close();flash(msg);return redirect(url_for("drivers"))
    c.close();return render_template("driver_form.html",x=old,edit=bool(id))
@app.route("/drivers/delete/<int:id>")
def driver_delete(id):
    c=db();c.execute("delete from drivers where id=?",(id,));c.commit();c.close();flash("Driver deleted!");return redirect(url_for("drivers"))

@app.route("/routes")
def routes():
    c=db();x=c.execute("""select routes.*,vehicles.vehicle_no,drivers.name driver_name from routes
    left join vehicles on routes.vehicle_id=vehicles.id left join drivers on routes.driver_id=drivers.id order by routes.id desc""").fetchall();c.close()
    return render_template("routes.html",rows=x)
@app.route("/routes/add",methods=["GET","POST"])
@app.route("/routes/edit/<int:id>",methods=["GET","POST"])
def route_form(id=None):
    c=db();old=c.execute("select * from routes where id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        data=(request.form["vehicle_id"],request.form["driver_id"],request.form["route_from"],request.form["route_to"],request.form["fare"] or 0,request.form["trip_date"],request.form["shift"])
        if id:c.execute("update routes set vehicle_id=?,driver_id=?,route_from=?,route_to=?,fare=?,trip_date=?,shift=? where id=?",data+(id,));msg="Route updated!"
        else:c.execute("insert into routes(vehicle_id,driver_id,route_from,route_to,fare,trip_date,shift) values(?,?,?,?,?,?,?)",data);msg="Route added!"
        c.commit();c.close();flash(msg);return redirect(url_for("routes"))
    vs=c.execute("select * from vehicles").fetchall();ds=c.execute("select * from drivers").fetchall();c.close()
    return render_template("route_form.html",x=old,vs=vs,ds=ds,edit=bool(id),today=date.today().isoformat())
@app.route("/routes/delete/<int:id>")
def route_delete(id):
    c=db();c.execute("delete from expenses where route_id=?",(id,));c.execute("delete from routes where id=?",(id,));c.commit();c.close();flash("Route deleted!");return redirect(url_for("routes"))

@app.route("/expenses")
def expenses():
    c=db();x=c.execute("""select expenses.*,vehicles.vehicle_no,routes.route_from,routes.route_to from expenses
    left join routes on expenses.route_id=routes.id left join vehicles on routes.vehicle_id=vehicles.id order by expenses.id desc""").fetchall()
    total=c.execute("select coalesce(sum(amount),0) from expenses").fetchone()[0];c.close();return render_template("expenses.html",rows=x,total=total)
@app.route("/expenses/add",methods=["GET","POST"])
@app.route("/expenses/edit/<int:id>",methods=["GET","POST"])
def expense_form(id=None):
    c=db();old=c.execute("select * from expenses where id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        data=(request.form["route_id"],request.form["expense_type"],request.form["amount"] or 0,request.form["note"],request.form["expense_date"])
        if id:c.execute("update expenses set route_id=?,expense_type=?,amount=?,note=?,expense_date=? where id=?",data+(id,));msg="Expense updated!"
        else:c.execute("insert into expenses(route_id,expense_type,amount,note,expense_date) values(?,?,?,?,?)",data);msg="Expense added!"
        c.commit();c.close();flash(msg);return redirect(url_for("expenses"))
    rs=c.execute("select routes.*,vehicles.vehicle_no from routes left join vehicles on routes.vehicle_id=vehicles.id").fetchall();c.close()
    return render_template("expense_form.html",x=old,rs=rs,edit=bool(id),today=date.today().isoformat())
@app.route("/expenses/delete/<int:id>")
def expense_delete(id):
    c=db();c.execute("delete from expenses where id=?",(id,));c.commit();c.close();flash("Expense deleted!");return redirect(url_for("expenses"))

@app.route("/attendance")
def attendance():
    c=db();rows=c.execute("select attendance.*,drivers.name from attendance left join drivers on attendance.driver_id=drivers.id order by attendance.attendance_date desc").fetchall()
    summary=c.execute("""select drivers.name,sum(case when status='Full Day' then 1 else 0 end) full_days,
    sum(case when status='Half Day' then 1 else 0 end) half_days,count(attendance.id) total from drivers left join attendance on drivers.id=attendance.driver_id group by drivers.id""").fetchall()
    c.close();return render_template("attendance.html",rows=rows,summary=summary)
@app.route("/attendance/add",methods=["GET","POST"])
@app.route("/attendance/edit/<int:id>",methods=["GET","POST"])
def attendance_form(id=None):
    c=db();old=c.execute("select * from attendance where id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        data=(request.form["driver_id"],request.form["attendance_date"],request.form["status"],request.form["shift"])
        if id:c.execute("update attendance set driver_id=?,attendance_date=?,status=?,shift=? where id=?",data+(id,));msg="Attendance updated!"
        else:c.execute("insert into attendance(driver_id,attendance_date,status,shift) values(?,?,?,?)",data);msg="Attendance saved!"
        c.commit();c.close();flash(msg);return redirect(url_for("attendance"))
    ds=c.execute("select * from drivers").fetchall();c.close();return render_template("attendance_form.html",x=old,ds=ds,edit=bool(id),today=date.today().isoformat())
@app.route("/attendance/delete/<int:id>")
def attendance_delete(id):
    c=db();c.execute("delete from attendance where id=?",(id,));c.commit();c.close();flash("Attendance deleted!");return redirect(url_for("attendance"))
@app.route("/uploads/<filename>")
def file(filename):return send_from_directory(UP,filename)
if __name__=="__main__":init();app.run(debug=True)
