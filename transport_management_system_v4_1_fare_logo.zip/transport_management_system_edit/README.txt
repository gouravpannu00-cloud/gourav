TRANSPORT MANAGEMENT SYSTEM V4

V4 FEATURES:
- CIRCLE LOGO in the header before the large Transport Management System title.
- Light background with a very soft logo watermark.
- Large 3 x 2 dashboard summary cards.
- Dashboard Add Vehicle, Driver, Route, Expense and Attendance buttons.
- Vehicle, Driver, Route, Expense and Attendance cards are clickable/touchable.
- Edit and Delete options.
- Vehicle/Driver document uploads.
- Route fare, expenses, profit.
- Full Day / Half Day attendance and total attendance.
- Day/Night mode with blinking stars.

RUN:
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Terminal: pip install -r requirements.txt
4. Run: python app.py
5. Open: http://127.0.0.1:5000
